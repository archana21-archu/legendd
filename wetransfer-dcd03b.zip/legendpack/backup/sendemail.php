<?PHP
######################################################
#                                                    #
#                Forms To Go 3.2.1                   #
#             http://www.bebosoft.com/               #
#                                                    #
######################################################






error_reporting(E_ERROR | E_WARNING | E_PARSE);
ini_set('track_errors', true);

function DoStripSlashes($FieldValue) 
{ 
 if ( get_magic_quotes_gpc() ) { 
  if (is_array($FieldValue) ) { 
   return array_map('DoStripSlashes', $FieldValue); 
  } else { 
   return stripslashes($FieldValue); 
  } 
 } else { 
  return $FieldValue; 
 } 
}

#----------
# FilterCChars:

function FilterCChars($TheString)
{
 return preg_replace('/[\x00-\x1F]/', '', $TheString);
}


if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
 $ClientIP = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
 $ClientIP = $_SERVER['REMOTE_ADDR'];
}

$FTGtxtName = DoStripSlashes( $_REQUEST['txtName'] );
$FTGtxtEmail = DoStripSlashes( $_REQUEST['txtEmail'] );
$FTGtxtPhone = DoStripSlashes( $_REQUEST['txtPhone'] );
$FTGtxtMessage = DoStripSlashes( $_REQUEST['txtMessage'] );
$FTGSubmit = DoStripSlashes( $_REQUEST['Submit'] );



# Include message in error page and dump it to the browser

if ($ValidationFailed === true) {

 $ErrorPage = '<html><head><title>Error</title></head><body>Errors found: <!--VALIDATIONERROR--></body></html>';

 $ErrorPage = str_replace('<!--VALIDATIONERROR-->', $ErrorList, $ErrorPage);
 $ErrorPage = str_replace('<!--FIELDVALUE:txtName-->', $FTGtxtName, $ErrorPage);
 $ErrorPage = str_replace('<!--FIELDVALUE:txtEmail-->', $FTGtxtEmail, $ErrorPage);
 $ErrorPage = str_replace('<!--FIELDVALUE:txtPhone-->', $FTGtxtPhone, $ErrorPage);
 $ErrorPage = str_replace('<!--FIELDVALUE:txtMessage-->', $FTGtxtMessage, $ErrorPage);
 $ErrorPage = str_replace('<!--FIELDVALUE:Submit-->', $FTGSubmit, $ErrorPage);
  

 echo $ErrorPage;
 exit;

}
# Email to Form Owner

$emailSubject = FilterCChars("Request from $FTGtxtName - from web page");

$emailBody = "--FTG_BOUNDRY\n"
 . "Content-Type: text/plain; charset=\"ISO-8859-1\"\n" 
 . "Content-Transfer-Encoding: 8bit\n"
 . "\n"
 . "Dear Team,\n"
 . "\n"
 . "There is a request from a visitor/customer from online website.\n"
 . "\n"
 . "Details:\n"
 . "-----------------------------------\n"
 . "\n"
 . "txtName : $FTGtxtName\n"
 . "txtEmail : $FTGtxtEmail\n"
 . "txtPhone : $FTGtxtPhone\n"
 . "txtMessage : $FTGtxtMessage\n"
 . "\n"
 . "-----------------------------------\n"
 . "\n"
 . "Thanks\n"
 . "$FTGtxtName\n"
 . ""
 . "\n"
 . "--FTG_BOUNDRY\n"
 . "Content-Type: text/html; charset=\"ISO-8859-1\"\n"
 . "Content-Transfer-Encoding: base64\n"
 . "\n"
 . chunk_split(base64_encode("<html>\n"
 . "<head>\n"
 . "<title></title>\n"
 . "</head>\n"
 . "<body>\n"
 . "Dear Team,<br/><br/>\n"
 . "\n"
 . "There is a request from a visitor/customer from online website.<br/><br/>\n"
 . "\n"
 . "Details:<br/>\n"
 . "-----------------------------------<br/><br/>\n"
 . "\n"
 . "txtName : $FTGtxtName<br/>\n"
 . "txtEmail : $FTGtxtEmail<br/>\n"
 . "txtPhone : $FTGtxtPhone<br/>\n"
 . "txtMessage : $FTGtxtMessage<br/><br/>\n"
 . "\n"
 . "-----------------------------------<br/><br/>\n"
 . "\n"
 . "Thanks<br/>\n"
 . "$FTGtxtName<br/>\n"
 . "</body>\n"
 . "</html>\n"
 . ""))
 . "\n"
 . "--FTG_BOUNDRY--";
 $emailTo = 'Legend Packers <legendpackers@gmail.com>';
  
 $emailFrom = FilterCChars("$FTGtxtEmail");
  
 $emailHeader = "From: $emailFrom\n"
  . "MIME-Version: 1.0\n"
  . "Content-Type: multipart/alternative; boundary=\"FTG_BOUNDRY\"\n"
  . "\n";
  
 mail($emailTo, $emailSubject, $emailBody, $emailHeader);


# Confirmation Email to User

$confEmailTo = FilterCChars($FTGtxtEmail);

$confEmailSubject = FilterCChars("Acknowledgement - Request Received");

$confEmailHeader = "From: legendpackers@gmail.com\n"
 . "MIME-Version: 1.0\n"
 . "Content-Type: multipart/alternative; boundary=\"FTG_BOUNDRY\"\n"
 . "\n";

$confEmailBody = "--FTG_BOUNDRY\n"
 . "Content-Type: text/plain; charset=\"ISO-8859-1\"\n" 
 . "Content-Transfer-Encoding: 8bit\n"
 . "\n"
 . "Dear $FTGtxtName,\n"
 . "\n"
 . "Thank you for sending the request from our web form. Our team will revert to you soon. \n"
 . "\n"
 . "Regards,\n"
 . "\n"
 . "Legend Packers & Movers\n"
 . "http://www.legendpackers.in"
 . "\n"
 . "--FTG_BOUNDRY\n"
 . "Content-Type: text/html; charset=\"ISO-8859-1\"\n"
 . "Content-Transfer-Encoding: base64\n"
 . "\n"
 . chunk_split(base64_encode("<html>\n"
 . "<head>\n"
 . "<title>Request Acknowledgement</title>\n"
 . "</head>\n"
 . "<body>\n"
 . "Dear $FTGtxtName,<br/><br/>\n"
 . "\n"
 . "Thank you for sending the request from our web form. Our team will revert to you soon. <br/><br/>\n"
 . "\n"
 . "Regards,<br/><br/>\n"
 . "\n"
 . "Legend Packers & Movers<br/>\n"
 . "http://www.legendpackers.in<br/>\n"
 . "</body>\n"
 . "</html>\n"
 . ""))
 . "\n"
 . "--FTG_BOUNDRY--";

mail($confEmailTo, $confEmailSubject, $confEmailBody, $confEmailHeader);

# Include message in the success page and dump it to the browser

$SuccessPage = '<html><head><title>Success</title></head><body>Form submitted successfully. It will be reviewed soon.</body></html>';

$SuccessPage = str_replace('<!--FIELDVALUE:txtName-->', $FTGtxtName, $SuccessPage);
$SuccessPage = str_replace('<!--FIELDVALUE:txtEmail-->', $FTGtxtEmail, $SuccessPage);
$SuccessPage = str_replace('<!--FIELDVALUE:txtPhone-->', $FTGtxtPhone, $SuccessPage);
$SuccessPage = str_replace('<!--FIELDVALUE:txtMessage-->', $FTGtxtMessage, $SuccessPage);
$SuccessPage = str_replace('<!--FIELDVALUE:Submit-->', $FTGSubmit, $SuccessPage);

echo $SuccessPage;
exit;
?>